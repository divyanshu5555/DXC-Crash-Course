package com.assessment.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.assessment.dbutil.DbConnection;

public class CustomerDao {
	
	public String saveCustomer(String custName,String custLastName,String custAddress ) {
		try {
			
			Connection con = DbConnection.getConnection();
			
			
			
					String sql="insert into customer values(?,?,?,?)";

			PreparedStatement stat=con.prepareStatement(sql);
			
			
			String seqsql="select custIdSeq.nextVal from dual";
			PreparedStatement state=con.prepareStatement(seqsql);
			ResultSet rs=state.executeQuery();
			int sequence=0;
			if(rs.next()){
				sequence=rs.getInt(1);
			}

			stat.setString(1, custName);
			stat.setString(2, custLastName);
			stat.setString(3, getNewId(custName,custLastName,sequence));
			stat.setString(4, custAddress);
			


			int res= stat.executeUpdate();
			if(res>0)
			return "Customer saved";


			}
			catch (Exception e) {
			e.printStackTrace();
			}

			return "Cannot save Customer";

			}
				
			
		public String getNewId(String custName, String custLastName , int seq) {
			String str;
			if(seq<10) {
				str=custName.substring(0, 2)+custLastName.substring(0, 2)+"00"+seq;
			return str;
			}
			else if(seq<100) {
				str=custName.substring(0, 2)+custLastName.substring(0, 2)+"0"+seq;
				return str;
			}
			
			else if(seq<1000) {
				str=custName.substring(0, 2)+custLastName.substring(0, 2)+seq;
				return str;
			}
			return null;
		}
				
				
				
			
}
