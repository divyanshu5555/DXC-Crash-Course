package com.assessment.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.assessment.dbutil.DbConnection;
import com.assessment.pogos.Customer;

public class CustomerDao {
	
	public String saveCustomer(Customer customer) {
		try {
			
			Connection con = DbConnection.getConnection();
			
			
			
					String sql="insert into customer values(?,?,?,?)";

			PreparedStatement stat=con.prepareStatement(sql);
			
			
			String seqsql="select custIdSeq.nextVal from dual";
			PreparedStatement state=con.prepareStatement(seqsql);
			ResultSet rs=state.executeQuery();
			int sequence=0;
			if(rs.next()){
				sequence=rs.getInt(1);
			}

			customer.setCustId( getNewId(customer.getCustName(),customer.getCustLastName(),sequence));

			stat.setString(1, customer.getCustName());
			stat.setString(2, customer.getCustLastName());
			stat.setString(3, customer.getCustId());
			stat.setString(4, customer.getCustAddress());
			


			int res= stat.executeUpdate();
			if(res>0)
			return "Customer saved";


			}
			catch (Exception e) {
			e.printStackTrace();
			}

			return "Cannot save Customer";

			}
				
			
		public String getNewId(String custName, String custLastName , int seq) {
			String str;
			if(seq<10) {
				str=custName.substring(0, 2)+custLastName.substring(0, 2)+"00"+seq;
			return str;
			}
			else if(seq<100) {
				str=custName.substring(0, 2)+custLastName.substring(0, 2)+"0"+seq;
				return str;
			}
			
			else if(seq<1000) {
				str=custName.substring(0, 2)+custLastName.substring(0, 2)+seq;
				return str;
			}
			return null;
		}
				
				
				
			
}
