package com.assessment.service;

import com.assessment.dao.*;
import com.assessment.dbutil.*;
import com.assessment.pogos.*;
//import com.sun.tools.javac.resources.compiler;

public class CustomerService {
	
	
	public static void main(String[] args) {
		
		
		CustomerDao customer =new CustomerDao();
		
		System.out.println(customer.saveCustomer("Divyanshu","Pandey","Kidwai Nagar"));
		System.out.println(customer.saveCustomer("Virat","Kohli","Delhi"));
		
	
	}
	
	
}
