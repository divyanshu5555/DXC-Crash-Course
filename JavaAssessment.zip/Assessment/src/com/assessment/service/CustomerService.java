package com.assessment.service;

import com.assessment.dao.*;
import com.assessment.dbutil.*;
import com.assessment.pogos.*;
//import com.sun.tools.javac.resources.compiler;

public class CustomerService {
	
	
	public static void main(String[] args) {
		
		
		Customer customer =new Customer("Avanish", "Kumar", "Kidwai Nagar");
		
	     CustomerDao c1=new CustomerDao();
	     c1.saveCustomer(customer);
		
		
	
	}
	
	
}
