package com.assessment.pogos;

public class Customer {
	
	private String custName;
	private String custLastName;
	private String custId;
	private String custAddress;
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getCustLastName() {
		return custLastName;
	}
	public void setCustLastName(String custLastName) {
		this.custLastName = custLastName;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public String getCustAddress() {
		return custAddress;
	}
	public void setCustAddress(String custAddress) {
		this.custAddress = custAddress;
	}
	public Customer(String custName, String custLastName, String custId, String custAddress) {
		super();
		this.custName = custName;
		this.custLastName = custLastName;
		this.custId = custId;
		this.custAddress = custAddress;
	}
	public Customer() {
		
	}
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return getCustName()+" "+getCustLastName()+" " +getCustId()+" " +getCustAddress();
	}
}
